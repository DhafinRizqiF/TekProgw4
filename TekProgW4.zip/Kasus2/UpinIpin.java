package Kasus2;

public class UpinIpin {
    
    public static void main(String[] args) {
        Item name = new Item("Upin");
    }
}
