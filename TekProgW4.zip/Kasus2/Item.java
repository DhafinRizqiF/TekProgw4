package Kasus2;

public class Item {
    private String name = "Ipin";
    
    private Item() {
        name = "Ipin";
    }
    public Item(String name){
        System.out.println(this.name);
    }
}
